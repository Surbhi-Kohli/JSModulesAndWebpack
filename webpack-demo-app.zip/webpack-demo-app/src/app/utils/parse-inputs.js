const parseInputs = (...input) => {
  return input.map(str => parseInt(str));
};
