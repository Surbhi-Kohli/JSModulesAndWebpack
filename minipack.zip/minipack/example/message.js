import {name} from './name.js';

export default `hello ${name}!`;
