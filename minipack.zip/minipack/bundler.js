const fs=require('fs');
const babylon=require('babylon');
const path=require('path')
const traverse=require('babel-traverse').default;

let ID=0;
/**
 * 
 * @param {string} filename -->absolute filepath is expected
 * @description:Takes path of a file and parses content to find dependencies
 */
function createAsset(filename){
  const content=fs.readFileSync(filename,'utf-8');
  const ast=babylon.parse(content,{
    sourceType:"module"
  })
  //console.log(ast);
  const dependencies=[]
  traverse(ast,{
      ImportDeclaration:({node})=>{
        //  console.log(node);
          dependencies.push(node.source.value);//always going to be string as we are using es modules
      }
  });
  //console.log(dependencies);
  const id=ID++;
  return {
      id,filename,dependencies
  }
}
//JS parser is a tool that knows and understands JS.It treats JS as a string and generates a model called AST-Abstråct syntax tree

function createGraph(entry){
    const mainAsset=createAsset(entry);
    const queue=[mainAsset];
    for(const asset of queue)
    {  const dirname=path.dirname(asset.filename);
        asset.mapping={};
        asset.dependencies.forEach(relativePath=>{
            const absolutePath=path.join(dirname,relativePath);
            const child=createAsset(absolutePath);
            asset.mapping[relativePath]=child.id;
            queue.push(child);
        })
    }
    return queue;
}
function bundle(graph){
    const modules='';
    graph.forEach(mod=>{
        modules+`${mod.id}:`
    })
const result=   `
  (function(){})({${modules}})
`
}
const graph=createGraph('./example/entry.js');
const result=bundle(graph);
console.log(result);
